# Be Awesome Admin
Free simple admin template build in Semantic-UI, AmChart and jQuery free for All license MIT

## How to use?
Download in github or pull master using git and enjoy using this template

## Where demo?
Demo you can see in http://muhibbudins.github.io/beawesomeadmin/

## Closing
Thanks for download and review, if you taking bug please report in Issue for maintenance this template. :D
